// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC_2BOIItoOPlgkcTYqkqvAekfa4axnBS0",
  authDomain: "tutorme2-chat-app.firebaseapp.com",
  projectId: "tutorme2-chat-app",
  storageBucket: "tutorme2-chat-app.appspot.com",
  messagingSenderId: "946078402000",
  appId: "1:946078402000:web:5484b8dad1c29f80f0e5d5",
  measurementId: "G-K56B7LXGYV"
};

// Initialize Firebase
 export const app = initializeApp(firebaseConfig);
 export const auth = getAuth();
 export const storage = getStorage();
 export const db = getFirestore()