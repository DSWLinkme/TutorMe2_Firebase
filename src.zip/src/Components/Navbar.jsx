import React, { useContext } from 'react'
import {signOut} from "firebase/auth"
import { auth } from '../firebase'
import { AuthContext } from '../Context/AuthContext'
import '../Pages/style.scss'


const Navbar = () => {
  const {currentUser} = useContext(AuthContext)

  return (
    <div className='navbar'>
      <span className="logo">TutorMe2</span>
      <div className="user">
        <img src={currentUser.photoURL} alt="" />
        <span>{currentUser.userName}</span>
        <button onClick={()=>signOut(auth)}>logout</button>
      </div>
    </div>
  )
}

export default Navbar;